### Третья итерация проекта
Добавлен typescript

Добавлен firebase