<script lang="ts" setup>
import { ref } from 'vue';
import { useRouter, RouterLink } from 'vue-router';
import useSignup from '../composables/useSignup';
import Input from '@/components/ui/Input.vue';
import Button from '@/components/ui/Button.vue';
import Login from '../components/Login/Login.vue';

const isSignup = ref(true);

const displayName = ref('');
const email = ref('');
const password = ref('');

const { signup, error } = useSignup();
const router = useRouter();

const handleSubmit = async () => {
  await signup(email.value, password.value, displayName.value);

  if(!error.value) {
    router.push('/home');
  }
}
</script>

<template>
  <div class="auth-box" v-if="isSignup">
    <div class="title">
      <span @click="isSignup = false">Регистрация</span> | 
      <span @click="isSignup = true">Вход</span>
    </div>
    <form @submit.prevent="handleSubmit">
      <div class="modal-auth__body">
        <Input 
          inputType="text" 
          :required="true"
          placeholder="Имя"
          v-model="displayName"
        />
        <Input 
          inputType="email" 
          :required="true"
          placeholder="Почта"
          v-model="email"
        />
        <Input 
          inputType="password" 
          :required="true"
          placeholder="Пароль"
          v-model="password"
        />
        <div class="btn-block">
          <Button size="md" @click="handleSubmit">Регистрация</Button>
        </div>
        <div v-if="error" class="err-msg">{{ error }}</div>
      </div>
    </form>
  </div>
  <Login v-else/>
</template>

<style>
.auth-box {
  max-width: 400px;
  margin: 50px auto;
  position: relative;
}

.err-msg {
  position: absolute;
  top: -30px;
  left: 0;
  font-size: 12px;
  color: red;
}
</style>