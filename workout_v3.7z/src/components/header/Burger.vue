<script setup lang="ts">
import Icon from '@/components/ui/Icon.vue';

</script>

<template>
  <div class="a11y-wrap">
    <Icon iconName="grid-2" width="20px"/>
  </div>
</template>