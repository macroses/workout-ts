<script setup lang="ts">
import Icon from '../ui/Icon.vue';
</script>

<template>
  <label class="switcher-box">
    <input type="checkbox" class="input-switch">
    <span class="switcher">
      <Icon width="10px" iconName="sun-bright"/>
    </span>
  </label>
</template>